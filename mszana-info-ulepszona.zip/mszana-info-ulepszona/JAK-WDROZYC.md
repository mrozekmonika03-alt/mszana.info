# Mszana INFO — wersja ulepszona 🛠️

Kompletny serwis (główna strona + 4 artykuły + wszystkie grafiki) po poprawkach i ulepszeniach.

## Co zostało zrobione

### 🆕 Runda 2 (najnowsze zmiany)
- **Sekcja „Ważna informacja — zasady naszej grupy”** — pełny regulamin grupy FB dodany między Forum a Mapą (link „📜 Zasady” w menu nagłówka i stopce).
- **Ogłoszenia przeniesione na sam dół strony** — teraz kolejność: Aktualności → Forum → Mapa/Sołtysi → **📢 Ogłoszenia** → **🎬 Wideo** → Stopka.
- **Tytuł strony** (zakładka przeglądarki + podgląd przy udostępnianiu): `Mszana INFO — Mszana – Przejrzysta Gmina & Sprawy Mieszkańców`. Nazwa grupy FB widoczna też w podtytule nagłówka i stopce.
- **Górny pasek przestawiony**: pierwszy od lewej **📧 kontakt@mszana.info**, potem **f Grupa → f Gmina → Gmina Mszana (z herbern) → 💬 Forum → 🎬 Workout → 👥 Radni → 🗺️ Okręgi**.
- **Sekcja wideo na samym dole (pod ogłoszeniami)**: osadzony film YouTube (Taneczny Workout Cardio z hitami Sanah) odtwarzany **od 7:00 do 9:30** (`start=420&end=570`), z pełnym tytułem i opisem.
- **„Film wskakuje na górę, spełza na dół”**: czerwony baner-promo na samej górze strony (pod nagłówkiem) + przycisk „🎬 Workout” w górnym pasku — kliknięcie przenosi płynnie na sam dół, do wideo.
- Link „🎬 Wideo” dodany też do nawigacji nagłówka i stopki.

### ✅ Poprawki („popraw”)
- **Zdublowane przyciski w górnym pasku** (e-mail ×3, „Radni/Okręgi” ×2) — usunięte, każdy link jest teraz raz.
- **Literówka kategorii** `bezpeiczenstwo` → `bezpieczenstwo` — wątek „Nie świeci latarnia…” w końcu pokazuje się w zakładce „Bezpieczeństwo”.
- **3× zdublowany wątek sesji** na forum (ten sam temat 3 razy) — usunięte 2 kopie.
- **Zdublowana linia zapisu** do localStorage — usunięta.
- **Usunięty „śmieciowy” tekst w stopce** („Otwórz grafikę forum…”).
- **Błędne CSS `.active-cat`** (`ring:` → poprawny `box-shadow`).
- **Niedziałająca liczba dyskusji** w hero (sztywno „14”) — teraz liczona automatycznie z danych forum.

### 🛡️ Herb Gminy Mszana („wstaw dodatkowo herb”)
- Twój herb wstawiony w **4 miejscach**: pasek górny (przycisk „Gmina Mszana”), nagłówek (obok „Mszana INFO”), karta „Oficjalne kanały gminy” oraz **stopka**.
- Przygotowany jako czysty plik `assets/herb-mszana.png` (obcięte białe marginesy).
- Herb jako **favicon** (`assets/favicon.png`) + ikona Apple (`assets/apple-touch-icon.png`).

### ✨ Ulepszenia („ulepsz”)
- **Meta tagi Open Graph** — po udostępnieniu na FB/WhatsApp strona pokaże ładną kartę z bannerem `assets/og-mszana-info.png` (wygenerowany: herb + „Mszana INFO”).
- **Favicon + theme-color** — zakładka przeglądarki i pasek adresu w kolorze zieleni/szałwi.
- **Responsywny górny pasek** — na telefonie ważne linki się nie rozjeżdżają (przewijane, „Radni/Okręgi” na mniejszych ekranach schowane).
- **Stopka przeprojektowana** — herb + nawigacja + oficjalne kanały + stopka prawna.
- **Accessibility**: `aria-label` dla nawigacji i pól wyszukiwania, `alt` dla obrazków, `scroll-margin-top` (kotwice nie chowają się pod przyklejonym paskiem).

## Jak wdrożyć na Netlify

1. Zaloguj się na https://app.netlify.com (konto, na którym jest `mszana-info`).
2. Otwórz witrynę **mszana-info** → zakładka **Deploys**.
3. Przeciągnij **cały folder `mszana-info-ulepszona`** w pole „Drag and drop your site folder here”.
4. Netlify zbuduje nowy deploy — gotowe w ~30 s. Stary deploy zostanie zachowany (można cofnąć).

> ⚠️ Wgrywaj **cały folder** (zawiera `artykuly/` i `assets/`), żeby nie zniknęły podstrony artykułów.

### Opcjonalnie — linia poleceń (CLI)
```bash
cd mszana-info-ulepszona
npx netlify-cli deploy --prod --dir .
```

## Struktura
```
mszana-info-ulepszona/
├── index.html            ← ulepszona strona główna
├── artykuly/             ← 4 artykuły (poprawione)
└── assets/
    ├── herb-mszana.png   ← nowy (herb, czysty)
    ├── favicon.png       ← nowy
    ├── apple-touch-icon.png ← nowy
    └── og-mszana-info.png   ← nowy (banner do udostępnień)
```
